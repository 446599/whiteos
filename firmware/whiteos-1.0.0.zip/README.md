# WhiteOS 1.0.0

Local firmware package built on 2026-10-09 for the 4.7-inch Read Pico
(ESP32-S3, 16 MB Flash). The application descriptor and manifest both use 1.0.0.

The firmware directory follows the whiteos website's flash/README.md contract:

| File | Role | Flash Address |
| --- | --- | --- |
| firmware/bootloader.bin | Bootloader | 0x00000 |
| firmware/partition-table.bin | Partition table | 0x08000 |
| firmware/whiteos.bin | Application | 0x10000 |
| firmware/manifest.json | Version, addresses, sizes and SHA-256 | Not flashed |

Addresses come from this build's ESP-IDF flasher_args.json. The manifest records
the actual bytes and hashes. Install selects all three images; update selects
only whiteos.bin. The application image must be written at 0x10000.

The existing NVS, PHY and storage layout is retained. The product configuration
uses the board's 120 MHz Flash/PSRAM timing; the ROM image header and flasher
parameters use DIO, 16 MB, 80 MHz. The EegoRead reader baseline remains
32341ecbefe74a11df3fa53ba92e9d7c6894cf6e. The build includes the existing
shutdown flow that presents the powered-off message before PMU shutdown.

ESP-IDF v6.1 compilation, image checksum/hash verification, product profile,
memory layout, WeRead linkage, USB eject linkage and USB host lifecycle tests
passed. The website's own manifest, image, partition and mode validators passed.
Build provenance and verification results are recorded in build-info.json.
SHA256SUMS covers the images, manifest and package metadata.

This 1.0.0 build has not been flashed, boot-tested or optically accepted on a
device, and has not been publicly published. The website firmware source has
not been enabled. Device acceptance remains necessary before publication under
the website repository's rules.

The ZIP excludes private build logs, ELF/map files, development paths and source
hash lists. Existing upstream license and notice files are preserved in licenses/;
see THIRD_PARTY_NOTICES.md for their scope.
